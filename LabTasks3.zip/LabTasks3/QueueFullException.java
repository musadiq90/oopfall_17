package LabTasks;

public class QueueFullException extends Exception{
    public QueueFullException()
    {
        System.out.println("Your Queue is Full");
    }
}
