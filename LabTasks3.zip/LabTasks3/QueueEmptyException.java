package LabTasks;



public class QueueEmptyException extends Exception {
    public QueueEmptyException(){
        System.out.println("Your Queue is Empty");
    }
}
